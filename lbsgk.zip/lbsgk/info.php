<?php


$template_directory = 'lbsgk';
$template_name = 'LBSGK';
$template_version = '3.1';
$template_platform = '2.10.x';
$template_author = 'Lars Becker';
$template_license = 'GPL';
$template_description = 'Made for SG Kornburg e.V.';

$block[1]='Main Content';
$block[2]='Left Bar'; 

$menu[1]='Standard';
$menu[2]='None'; 

?>