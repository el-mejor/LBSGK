# LBSGK
WebsiteBaker Template for http://www.sg-kornburg.de 

Sorry for the mess :-(

If you like it, feel free to use and adapt it for your own project. 

More information about WebsiteBaker CMS: www.websitebaker.org
